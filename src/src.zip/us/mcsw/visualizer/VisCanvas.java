package us.mcsw.visualizer;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

public class VisCanvas extends Canvas {

	private static final long serialVersionUID = -3751853183360176775L;
	
	public VisCanvas() {
		setPreferredSize(new Dimension(800, 800));
		setSize(new Dimension(800, 800));
	}
	
	@Override
	public void paint(Graphics g) {
		super.paint(g);
		g.setColor(Color.black);
		g.fillRect(0, 0, getWidth(), getHeight());
		Visualizer.draw((Graphics2D) g);
	}

}
