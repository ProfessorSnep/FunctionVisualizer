package us.mcsw.visualizer;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.ArrayList;

public class Visualizer {

	// number of pixels per 1-number increase of graph
	static final int scale = 25;

	static final int size = 800;

	public static void draw(Graphics2D g) {
		// Curved Axes
		drawFunction(g, new FunctionRunnable() {
			public double[] run(double x) {
				return new double[] { x * x };
			}
		}, 10000, Color.gray);
		drawFunction(g, new FunctionRunnable() {
			public double[] run(double x) {
				if (x >= 0) {
					return new double[] { Math.sqrt(x), -Math.sqrt(x) };
				}
				return new double[] {};
			}
		}, 10000, Color.darkGray);

		// Straight Axes
		// drawFunction(g, new FunctionRunnable() {
		// public double[] run(double x) {
		// return new double[] { 0 };
		// }
		// }, 10000, Color.gray);
		// drawPiecewise(g, new VerticalLineFunction(0), -(size / scale), size /
		// scale, 10000, Color.darkGray);

		FunctionRunnable compare = new FunctionRunnable() {
			public double[] run(double x) {
				return new double[] { x * x };
			}
		};
		// drawFunction(g, compare, 100000, Color.red);
		drawPiecewise(g, new CurvedAxesFunction(compare), -(size / scale), size / scale, 100000, Color.cyan);
	}

	/********************
	 * HELPER FUNCTIONS *
	 ********************
	 */

	public static void drawFunction(Graphics2D g, FunctionRunnable func, int steps, Color color) {
		drawPiecewise(g, func, -(size / scale), (size / scale), steps, color);
	}

	public static void drawPiecewise(Graphics2D g, PiecewiseRunnable func, double ti, double te, int steps,
			Color color) {
		g.setColor(color);
		double t = ti;
		double incr = (te - ti) / (double) steps;
		for (int si = 0; si < steps; si++) {
			try {
				Point[] vals = func.runPiece(t);
				for (Point p : vals) {
					Point dr = p.toPixel();
					g.drawRect((int) dr.x, (int) dr.y, 1, 1);
				}
			} catch (ArithmeticException e) {
				e.printStackTrace();
			}
			t += incr;
		}
	}

	public static interface PiecewiseRunnable {
		public Point[] runPiece(double t);
	}

	public static abstract class FunctionRunnable implements PiecewiseRunnable {

		public abstract double[] run(double x);

		public Point[] runPiece(double t) {
			ArrayList<Point> ret = new ArrayList<>();
			for (double d : run(t)) {
				ret.add(new Point(t, d));
			}
			return ret.toArray(new Point[0]);
		}
	}

	public static class VerticalLineFunction implements PiecewiseRunnable {

		double x = 0;

		public VerticalLineFunction(double x) {
			this.x = x;
		}

		@Override
		public Point[] runPiece(double t) {
			return new Point[] { new Point(x, t) };
		}

	}

	public static class CurvedAxesFunction implements PiecewiseRunnable {

		FunctionRunnable run;

		public CurvedAxesFunction(FunctionRunnable run) {
			this.run = run;
		}

		@Override
		public Point[] runPiece(double t) {
			double[] r = run.run(t);
			Point[] ret = new Point[r.length];
			for (int i = 0; i < r.length; i++) {
				ret[i] = new Point((r[i] * r[i]) + t, (t * t) + r[i]);
			}
			return ret;
		}

	}

	public static class Point {
		public double x, y;

		public Point(double x, double y) {
			this.x = x;
			this.y = y;
		}

		public Point toPixel() {
			double cx = this.x;
			double cy = this.y;
			cx *= scale;
			cy *= scale;
			cx += size / 2;
			cy += size / 2;
			cy = size - cy;
			return new Point(cx, cy);
		}

		public Point toValue() {
			double cx = this.x;
			double cy = this.y;
			cy = size - cy;
			cx -= size / 2;
			cy -= size / 2;
			cx /= scale;
			cy /= scale;
			return new Point(cx, cy);
		}
	}

}
